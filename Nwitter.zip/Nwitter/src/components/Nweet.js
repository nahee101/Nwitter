import React, { useState } from "react";
import { doc, deleteDoc, updateDoc } from "firebase/firestore";
import { deleteObject, ref } from "firebase/storage";
import { dbService, storageService } from "fbase";
import { async } from "@firebase/util";

const Nweet = ({nweetObj, isOwner}) => {
    /* editing 모드인지 아닌지 */
    const [editing, setEditing] = useState(false);
    /* 업데이트 */
    const [newNweet, setNewNweet] = useState(nweetObj.text);

    //삭제하려는 이미지 파일을 가리키는 ref 생성하기
    const desertRef = ref(storageService, nweetObj.attachmentURL);

    const onDeleteClick = async () => {
        const ok = window.confirm("정말 이 트윗을 삭제하시겠습니까?");
            if (ok) {
                try {
                    //해당하는 트윗 파이어스토어에서 삭제
                    await deleteDoc(doc(dbService, `nweets/${nweetObj.id}`));
                    //삭제하려는 트윗에 이미지 파일이 있는 경우 이미지 파일 스토리지에서 삭제
                    if (nweetObj.attachmentUrl !== "") {
                        await deleteObject(desertRef);
                    }
                    } catch (error) {
                    window.alert("트윗을 삭제하는 데 실패했습니다!");
                }
            }
        };
    /* editing 모드 끄고 켜기 */
    const toggleEditting = () => setEditing((prev) => !prev);

    /* 업데이트 */
    const onSubmit = async (event) => {
        event.preventDefault();
        updateDoc(doc(dbService, "nweets", nweetObj.id), {text: newNweet});
        setEditing(false);
    };
    const onChange = (event) => {
        const {target: {value}} = event;
        setNewNweet(value);
    }

    return (
        <div key={nweetObj.id}>
            {
                editing ? (
                    <>
                        <form onSubmit={onSubmit}>
                            <input 
                            onChange={onChange}
                            type="text" 
                            placeholder="Edit your Nweet" 
                            value={newNweet} 
                            required />
                            <input
                            type="submit"
                            value="Update Nweet" />
                        </form>
                        <button onClick={toggleEditting}>Cancel</button>
                    </>
                ) : (
                    <>
                        <h4>{nweetObj.text}</h4>
                        {nweetObj.attachmentUrl && (
                            <img src={nweetObj.attachmentURL} width="50px" height="50px" />
                        )}
                        {isOwner && (
                            <>
                                <button onClick={onDeleteClick}>Delete Nweet</button>
                                <button onClick={toggleEditting}>Edit Nweet</button>
                            </>
                        )}
                    </>
                )
            }
        </div>
    );
};

export default Nweet;